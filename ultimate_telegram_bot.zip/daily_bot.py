import telebot
import schedule
import time
import random
import os

API_TOKEN = os.getenv("API_TOKEN")
CHANNEL_USERNAME = os.getenv("CHANNEL_USERNAME")

bot = telebot.TeleBot(API_TOKEN)

# Content banks
personal_development_quotes = [
    "Growth begins at the end of your comfort zone.",
    "Consistency beats motivation every single time.",
    "Your mindset determines your future.",
] * 50

bible_verses = [
    "Philippians 4:13 – I can do all things through Christ who strengthens me.",
    "Jeremiah 29:11 – 'For I know the plans I have for you,' declares the Lord.",
] * 25

business_growth_tips = [
    "Focus on building relationships, not just transactions.",
    "Discipline > Motivation: Show up even when you don’t feel like it.",
] * 25

trading_tips = [
    "Always wait for breakout confirmation; false breakouts are common.",
    "Define your capital risk before entry; always use protective stops.",
    "Use confirmation filters: intrabar, multiple closes, or percentage.",
    "Avoid seeing patterns where there are none; stay disciplined.",
] * 6

trading_mindset_tips = [
    "Discipline means following your plan even when it’s uncomfortable.",
    "Don’t chase losses; revenge trading only compounds mistakes.",
    "Focus on process over outcome; consistent habits = consistent profits.",
    "Detach your identity from trades; wins/losses don’t define you.",
] * 6

community_tasks = [
    "💬 Daily Task: Share one win and one lesson from today.",
    "👥 Comment below what your morning routine looks like.",
    "🔥 Challenge: Go 24 hours without complaining. Share your experience.",
    "📈 Post your biggest takeaway from this week’s trading sessions.",
    "💡 What’s one habit you're building this month? Comment below.",
    "📚 Share your favorite quote from the current book of the month.",
] * 5

monthly_books = [
    "📚 Book of the Month (Business): 'The 10X Rule' by Grant Cardone",
    "📚 Book of the Month (Mindset): 'Atomic Habits' by James Clear",
    "📚 Book of the Month (Personal Dev): 'The 7 Habits of Highly Effective People' by Stephen Covey",
    "📚 Book of the Month (Bonus): 'Think and Grow Rich' by Napoleon Hill",
]

motivational_images = [
    "https://i.imgur.com/1.jpg",
    "https://i.imgur.com/2.jpg",
]

def send_daily_post():
    category = random.choice([
        "personal", "bible", "business", "trading", "mindset", "task", "book"
    ])
    if category == "personal":
        message = random.choice(personal_development_quotes)
    elif category == "bible":
        message = random.choice(bible_verses)
    elif category == "business":
        message = random.choice(business_growth_tips)
    elif category == "trading":
        message = random.choice(trading_tips)
    elif category == "mindset":
        message = random.choice(trading_mindset_tips)
    elif category == "task":
        message = random.choice(community_tasks)
    else:
        message = random.choice(monthly_books)

    if random.choice([True, False]):
        bot.send_photo(CHANNEL_USERNAME, random.choice(motivational_images), caption=message)
    else:
        bot.send_message(CHANNEL_USERNAME, message)

def send_welcome_message():
    welcome_text = (
        "👋 Welcome to the channel, family!

"
        "This bot is here to inspire, teach, and empower you daily with:
"
        "📖 Bible verses
"
        "🧠 Mindset & personal growth tips
"
        "📊 Trading wisdom & psychology
"
        "📈 Business strategies
"
        "📚 Monthly book recommendations
"
        "✅ Community challenges

"
        "Let’s grow in faith, mindset, and success — together! 🙏💼🔥"
    )
    bot.send_message(CHANNEL_USERNAME, welcome_text)

# Schedule posts and welcome message
schedule.every().day.at("09:00").do(send_daily_post)
schedule.every().day.at("15:00").do(send_daily_post)
schedule.every().day.at("21:00").do(send_daily_post)

# One-time welcome message on launch
send_welcome_message()

print("Ultimate bot is running with all features...")

while True:
    schedule.run_pending()
    time.sleep(1)
